(function(){
    'use strict';
    const native=browser;let connection,documentPort;
    function documentToken(){
        if(!connection)connection=new Promise((resolve,reject)=>{
            const port=documentPort=native.runtime.connect({name:'caput-document-v1'});
            port.onMessage.addListener(message=>{if(message.kind==='CAPUT_DOCUMENT'&&typeof message.token==='string')resolve(message.token);});
            port.onDisconnect.addListener(()=>reject(new Error('Koneksi dokumen terputus. Refresh halaman MyIntress.')));
        });
        return connection;
    }
    globalThis.chrome={...native,runtime:{...native.runtime,sendMessage:async message=>native.runtime.sendMessage({...message,__caputDocument:await documentToken()})}};
})();
