/* Firefox event-page adapter; the validation engine remains shared with Chrome. */
(function(){
    'use strict';
    const native=browser,documents=new Map();
    native.runtime.onConnect.addListener(port=>{
        if(port.name!=='caput-document-v1')return;
        const sender=port.sender;
        let allowed=false;try{allowed=sender.id===native.runtime.id&&Number.isInteger(sender.tab?.id)&&sender.frameId===0&&new URL(sender.url).origin==='https://myintress.kemenkeu.go.id';}catch{}
        if(!allowed){port.disconnect();return;}
        const token=crypto.randomUUID();documents.set(token,{sender,port});
        port.onDisconnect.addListener(()=>documents.delete(token));
        port.postMessage({kind:'CAPUT_DOCUMENT',token});
    });
    const runtime={...native.runtime,onMessage:{addListener(listener){
        native.runtime.onMessage.addListener((message,sender,reply)=>{
            if(sender.id===native.runtime.id&&sender.url===native.runtime.getURL('popup.html'))return listener(message,sender,reply);
            const doc=documents.get(message?.__caputDocument);
            if(!doc||sender.id!==doc.sender.id||sender.tab?.id!==doc.sender.tab.id||sender.frameId!==0){reply({ok:false,error:'Koneksi dokumen Firefox tidak aktif. Refresh halaman MyIntress.'});return false;}
            const clean={...message};delete clean.__caputDocument;
            return listener(clean,{...sender,documentId:message.__caputDocument,documentLifecycle:'active'},reply);
        });
    }}};
    globalThis.chrome={...native,runtime};
    globalThis.importScripts=(...names)=>{
        if(names.length!==1||names[0]!=='core.js'||!globalThis.CaputCore)throw new Error('Core Firefox belum dimuat.');
    };
})();
