'use strict';
globalThis.chrome=browser;
