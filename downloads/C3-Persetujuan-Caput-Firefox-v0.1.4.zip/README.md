# C3 Persetujuan Caput, Mozilla Firefox 0.1.4

PAKET PEMASANGAN SEMENTARA, BELUM DITANDATANGANI MOZILLA.

## Pemasangan

1. Gunakan Firefox desktop versi 140 atau lebih baru (diuji pada Firefox 154.0.1).
2. Ekstrak ZIP ke folder tetap.
3. Buka about:debugging#/runtime/this-firefox.
4. Pilih Load Temporary Add-on / Muat Pengaya Sementara, lalu pilih manifest.json dari folder tadi.
5. Jika Firefox meminta izin akses situs, izinkan hanya untuk myintress.kemenkeu.go.id. Buka ulang/refresh tab detail MyIntress sebelum memakai ekstensi.

Pengaya sementara hilang ketika Firefox ditutup; muat lagi dengan langkah di atas. Jangan memasang ZIP ini lewat Add-ons Manager sebagai pengaya permanen. Pemasangan permanen membutuhkan XPI yang ditandatangani Mozilla melalui AMO. Paket ini tidak meminta kamu menonaktifkan pemeriksaan signature.

## Penggunaan dan keputusan

Pastikan seluruh hasil pemeriksaan C3 untuk satker/periode/tahun yang sama sudah valid. Buka detail MyIntress, periksa cakupan, jalankan Cek tanpa kirim, lalu centang keputusan pengguna sebelum Setujui seluruh baris X. Ekstensi bukan pembuat keputusan dan tidak mengabaikan hasil C3 yang masih perlu perbaikan.

Versi 0.1.4 menambahkan tombol mode Konfirmasi. Pilih Konfirmasi, Cek tanpa kirim, centang keputusan pengguna, lalu Konfirmasi - Setuju. Baris dengan teks tepat terkonfirmasi dilewati; status lain diproses melalui Action Konfirmasi -> Tambah Catatan -> Status Terkonfirmasi = terkonfirmasi -> Catatan = sesuai -> Kirim. Tidak menjalankan Action Validasi pada mode ini. Mode/antrean dikunci sampai selesai dan tetap sama setelah refresh; mengganti mode mereset centang persetujuan. Antrean lama tanpa mode tetap dibaca sebagai Validasi.

Pekerjaan tersimpan lokal per tab. Baris diproses berurutan melalui Status Validasi -> setuju -> Kirim, kemudian diperiksa hijau. Jika tabel hilang pada URL sama, dicoba lima refresh berturut-turut. Kiriman yang hasilnya belum pasti tidak dikirim ulang otomatis. Jika satker/periode/tahun/filter/nilai baris berubah atau sesi login habis, proses dijeda. Login/MFA dilakukan sendiri. Jangan mengubah filter saat berjalan.

Berhenti mencegah tindakan berikutnya, bukan membatalkan yang telah terkirim. Lanjutkan wajib keputusan pengguna lagi dan mempertahankan checkpoint. Simpan laporan mengunduh JSON yang mungkin berisi data pekerjaan, simpan sesuai kebijakan internal.

## Privasi dan pengujian

Akses hanya ke MyIntress. Tidak mengambil token/cookie/kata sandi dan tidak mengirim data ke website C3/server lain. Progres ada di storage lokal, bukan cloud. Koneksi port per dokumen mencegah dokumen lama menyimpan progres setelah refresh. Paket Chrome dan Firefox memakai engine validator yang sama.

Pengujian memakai profil terisolasi dan fixture sintetis, bukan persetujuan produksi. Bukan ekstensi resmi MyIntress. Gunakan hanya dalam kewenangan organisasi.

Rujukan pemasangan: https://extensionworkshop.com/documentation/develop/temporary-installation-in-firefox/
