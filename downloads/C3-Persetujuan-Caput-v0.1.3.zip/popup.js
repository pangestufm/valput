'use strict';
const $=id=>document.getElementById(id);
let tabId,job,available=false,reconnectable=false,waiting=false,refreshing=false,preview=null,actionError='';
let previewCounts=null;
function message(value,state=''){$('message').textContent=value;$('message').dataset.state=state;$('message').hidden=!value;}
function phase(label,state=''){$('phaseLabel').textContent=label;$('phaseLabel').dataset.state=state;}
function counts(total,pending=null,approved=null){$('totalCount').textContent=total??'-';$('pendingCount').textContent=pending??'-';$('approvedCount').textContent=approved??'-';}
function countMode(queue=false){
    $('resultTitle').textContent=queue?'Progres antrean':'Hasil pemeriksaan';
    $('countTotalLabel').textContent=queue?'Di antrean':'Total baris';
    $('countPendingLabel').textContent=queue?'Sisa antrean':'Menunggu / X';
    $('countApprovedLabel').textContent=queue?'Terbukti hijau':'Disetujui';
}
async function request(kind,extra={}){
    const response=await chrome.runtime.sendMessage({kind,tabId,...extra});
    if(!response?.ok)throw new Error(response?.error||'Ekstensi tidak merespons.');return response.value;
}
function controls(){
    const running=job&&['running','recovering'].includes(job.status);
    $('start').disabled=!available||waiting||running||!$('confirmed').checked;
    $('check').disabled=!available||waiting||running;
    $('resume').disabled=!(available||reconnectable)||waiting||!job||!['paused','stopped'].includes(job.status)||!$('confirmed').checked;
    $('report').disabled=!job;$('clear').disabled=!job||running||waiting;
    $('stop').disabled=!Number.isInteger(tabId)||(available&&!job&&!waiting);
}
async function refresh(){
    if(refreshing)return;refreshing=true;
    try{
        const state=await request('UI_STATUS');job=state.job;available=!!state.info;
        reconnectable=!available&&!!job?.scope&&!!state.connectionError;
        const info=state.info;
        const scope=info?.scope||job?.scope;
        if(!scope)throw new Error(state.connectionError||'Cakupan halaman belum siap.');
        $('scopeSatker').textContent=scope.satker;
        $('scopePeriod').textContent=scope.periode;$('scopeYear').textContent=info?.year||job.year;
        if(job&&['running','recovering'].includes(job.status))preview=null;
        if(preview){countMode();$('progress').textContent=preview;message('');phase('Sudah dicek','preview');counts(previewCounts.total,previewCounts.pending,previewCounts.approved);}
        else if(job){const done=job.queue.filter(r=>r.stage==='done').length;
            const labels={running:'Berjalan',recovering:'Memulihkan halaman',paused:'Dijeda',stopped:'Dihentikan',done:'Selesai'};
            $('progress').textContent=`${labels[job.status]||job.status}: ${done}/${job.queue.length} baris antrean terverifikasi hijau.`;
            message(job.status==='done'?'':job.message,job.status);phase(labels[job.status]||job.status,job.status);
            const left=job.queue.length-done;countMode(true);counts(job.queue.length,left,done);
            $('jobProgress').hidden=!runningState(job.status);$('jobProgress').max=Math.max(1,job.queue.length);$('jobProgress').value=done;
            if(['paused','stopped'].includes(job.status))$('jobDetails').open=true;
        }
        else{countMode();counts(info.total);$('jobProgress').hidden=true;if($('message').textContent==='Memproses…')message('');phase('Siap');}
        if(actionError){message(actionError,'error');phase('Perlu dicek','error');}
    }catch(error){available=false;reconnectable=false;message(`${error.message} Jika ekstensi baru dipasang, refresh halaman detail MyIntress.`,'error');phase('Belum terhubung','error');}
    finally{refreshing=false;}
    controls();
}
async function act(kind){
    if(waiting&&kind!=='UI_STOP')return;
    if(kind!=='UI_CHECK'){preview=null;previewCounts=null;}actionError='';
    waiting=true;message('Memproses…');phase(kind==='UI_CHECK'?'Memeriksa…':'Memproses…');controls();
    try{
        const result=await request(kind,{confirmed:$('confirmed').checked});
        if(kind==='UI_CHECK'){previewCounts=result;preview=`Cek tanpa kirim: ${result.total} baris; ${result.pending} X; ${result.approved} sudah disetujui. Tidak ada persetujuan dikirim.`;$('progress').textContent=preview;}
        if(kind==='UI_CLEAR'){job=null;$('progress').textContent='Riwayat lokal dihapus.';message('');}
        if(kind==='UI_STOP'&&!result){$('progress').textContent='Tidak ada pekerjaan aktif untuk dihentikan.';message('');}
        await refresh();
    }catch(error){actionError=error.message;message(actionError,'error');phase('Perlu dicek','error');}
    finally{waiting=false;controls();}
}
$('confirmed').addEventListener('change',controls);
for(const [id,kind]of Object.entries({start:'UI_START',check:'UI_CHECK',stop:'UI_STOP',resume:'UI_RESUME',clear:'UI_CLEAR'}))$(id).addEventListener('click',()=>void act(kind));
$('report').addEventListener('click',()=>{
    if(!job)return;const url=URL.createObjectURL(new Blob([JSON.stringify(job,null,2)],{type:'application/json'}));
    const a=document.createElement('a');a.href=url;a.download=`C3_Caput_${job.scope.satker}_${job.scope.periode}_${job.id}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),5000);
});
function runningState(status){return ['running','recovering'].includes(status);}
function theme(dark){document.documentElement.dataset.theme=dark?'dark':'light';$('theme').textContent=dark?'Tema terang':'Tema gelap';$('theme').setAttribute('aria-pressed',String(dark));}
$('version').textContent=chrome.runtime.getManifest().version;
theme(localStorage.getItem('theme')==='dark');
$('theme').addEventListener('click',()=>{const dark=document.documentElement.dataset.theme!=='dark';theme(dark);localStorage.setItem('theme',dark?'dark':'light');});
(async()=>{const [tab]=await chrome.tabs.query({active:true,currentWindow:true});tabId=tab?.id;await refresh();})();
setInterval(()=>{if(!waiting)void refresh();},1500);
