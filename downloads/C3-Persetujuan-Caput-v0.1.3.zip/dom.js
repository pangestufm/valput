(function(root){
    'use strict';
    const C=root.CaputCore;
    const norm=x=>C.normalize(x).toLowerCase();
    const compact=x=>norm(x).replace(/[^a-z0-9]/g,'');
    const visible=el=>!!el && !el.closest('[hidden],[aria-hidden="true"]') && el.getClientRects().length>0;
    const enabled=el=>visible(el)&&!el.disabled&&el.getAttribute('aria-disabled')!=='true'&&!el.classList.contains('p-disabled');
    const text=el=>C.normalize(el?.innerText ?? el?.textContent ?? '');
    class CaputDom {
        constructor({document:doc=root.document,url=root.location.href,timeout=20000}={}){
            this.doc=doc;this.url=url;this.scope=C.parseScope(url);this.timeout=timeout;
        }
        async wait(fn,message,guard=async()=>{},timeout=this.timeout){
            const end=Date.now()+timeout;
            do {await guard();const value=fn();if(value)return value;await new Promise(r=>setTimeout(r,180));}while(Date.now()<end);
            throw new Error(message);
        }
        headers(table){
            const matrix=[];
            [...(table.tHead?.rows||[])].forEach((row,r)=>{
                matrix[r] ||= [];let c=0;
                for(const cell of row.cells){
                    while(matrix[r][c]!==undefined)c++;
                    for(let dr=0;dr<(cell.rowSpan||1);dr++){
                        matrix[r+dr] ||= [];
                        for(let dc=0;dc<(cell.colSpan||1);dc++)matrix[r+dr][c+dc]=text(cell);
                    }
                    c+=cell.colSpan||1;
                }
            });
            return Array.from({length:Math.max(0,...matrix.map(r=>r.length))},(_,c)=>[...new Set(matrix.map(r=>r[c]).filter(Boolean))]);
        }
        table(){
            const matches=[];
            for(const table of this.doc.querySelectorAll('table')){
                if(!visible(table))continue;
                const heads=this.headers(table),leaf=i=>compact(heads[i]?.at(-1));
                const one=(predicate,label)=>{const ids=heads.map((_,i)=>i).filter(predicate);if(ids.length!==1)throw new Error(`Kolom ${label} tidak unik/tidak dikenali.`);return ids[0];};
                if(!heads.some(h=>compact(h.at(-1))==='kroro')||!heads.some(h=>compact(h.at(-1))==='program'))continue;
                const cols={program:one(i=>leaf(i)==='program','Program'),kegiatan:one(i=>leaf(i)==='kegiatan','Kegiatan'),
                    ro:one(i=>leaf(i)==='kroro','KRO/RO'),
                    status:one(i=>leaf(i)==='validasi'&&!heads[i].some(h=>/^(action|aksi)$/.test(norm(h))),'Status Validasi'),
                    action:one(i=>leaf(i)==='validasi'&&heads[i].some(h=>/^(action|aksi)$/.test(norm(h))),'Action Validasi')};
                matches.push({table,heads,cols,wrapper:table.closest('.p-datatable')||table.parentElement});
            }
            if(!matches.length)throw Object.assign(new Error('Tabel detail capaian RO belum siap.'),{code:'CAPUT_TABLE_UNAVAILABLE'});
            if(matches.length!==1)throw new Error('Tabel detail capaian RO tidak unik.');
            return matches[0];
        }
        status(cell){
            const icons=cell.querySelectorAll('i,svg,[data-p-icon],.p-button-icon,.pi');
            const descriptor=[...icons].map(el=>`${el.getAttribute('class')||''} ${el.getAttribute('data-p-icon')||''} ${el.getAttribute('aria-label')||''}`).join(' ');
            const label=norm(`${cell.getAttribute('aria-label')||''} ${text(cell)}`);
            const hasX=/\b(pi-times|pi-times-circle|fa-times|fa-xmark|fa-times-circle)\b|\btimes(icon)?\b/i.test(descriptor)||/^(x|×|✕|✗)$/.test(label);
            const hasCheck=/\b(pi-check|pi-check-circle|fa-check|fa-check-circle)\b|\bcheck(icon)?\b/i.test(descriptor)||/^(✓|✔)$/.test(label);
            if(hasX&&!hasCheck)return 'pending';
            if(hasCheck&&!hasX)return 'approved';
            if(/^(belum divalidasi|belum validasi|tidak divalidasi)$/.test(label))return 'pending';
            if(/^(sudah divalidasi|disetujui|setuju)$/.test(label))return 'approved';
            return 'unknown';
        }
        rows(){
            const ctx=this.table(),result=[];
            for(const tr of ctx.table.tBodies[0]?.rows||[]){
                const cells=[...tr.cells];if(cells.length!==ctx.heads.length)continue;
                const get=name=>text(cells[ctx.cols[name]]);
                const row={program:get('program'),kegiatan:get('kegiatan'),ro:get('ro'),status:this.status(cells[ctx.cols.status]),
                    values:cells.filter((_,i)=>i!==ctx.cols.status&&!ctx.heads[i].some(h=>/^(action|aksi)$/.test(norm(h)))).map(text),element:tr};
                C.rowKey(this.scope,row);result.push(row);
            }
            return result;
        }
        report(){
            const ctx=this.table(),report=ctx.wrapper.querySelector('.p-paginator-current');
            const m=text(report).match(/([\d.,]+)\s*-\s*([\d.,]+)\s*dari\s*([\d.,]+)\s*baris/i);
            if(m)return {first:Number(m[1].replace(/\D/g,'')),last:Number(m[2].replace(/\D/g,'')),total:Number(m[3].replace(/\D/g,''))};
            if(ctx.wrapper.querySelector('.p-paginator-next'))throw new Error('Jumlah baris/pagination tidak dikenali.');
            const count=this.rows().length;return {first:count?1:0,last:count,total:count};
        }
        signature(){return JSON.stringify({report:this.report(),rows:this.rows().map(r=>C.rowKey(this.scope,r))});}
        busy(){return !!this.doc.querySelector('.p-datatable-loading-overlay,.p-datatable-mask,.p-component-overlay.p-datatable-loading');}
        async ready(guard=async()=>{}){
            const message='Tabel tidak siap. Pastikan sudah login dan halaman detail terbuka.';
            try{return await this.wait(()=>{try{return !this.busy()&&this.table();}catch{return false;}},message,guard);}
            catch(error){
                if(error.message===message){try{this.table();}catch(tableError){if(tableError.code==='CAPUT_TABLE_UNAVAILABLE')throw tableError;}}
                throw error;
            }
        }
        year(){
            const m=text(this.doc.body).match(/Tahun\s*Anggaran\s*:?\s*(20\d{2})/i);
            if(!m)throw new Error('Tahun anggaran tidak terbaca. Proses tidak dimulai.');
            return m[1];
        }
        filters(){
            return [...this.table().wrapper.querySelectorAll('input')].filter(el=>visible(el)&&!el.readOnly&&!['hidden','checkbox','radio'].includes(el.type))
                .map(el=>({name:el.getAttribute('placeholder')||el.id||el.name||el.type,value:el.value}));
        }
        async changePage(button,guard=async()=>{}){
            if(!enabled(button))return false;
            const before=this.signature();await guard();button.click();
            await this.wait(()=>{try{return !this.busy()&&this.signature()!==before;}catch{return false;}},'Perpindahan halaman tidak selesai.',guard);
            return true;
        }
        async first(guard=async()=>{}){
            await this.ready(guard);
            const report=this.report();if(report.first<=1)return;
            const button=this.table().wrapper.querySelector('.p-paginator-first');
            if(!await this.changePage(button,guard))throw new Error('Tidak dapat kembali ke halaman pertama.');
        }
        async scan(guard=async()=>{}){
            await this.first(guard);const all=[],seen=new Set();let total=this.report().total;
            for(let page=0;page<200;page++){
                await guard();await this.ready(guard);
                const report=this.report();if(report.total!==total)throw new Error('Jumlah data berubah saat pemeriksaan. Ulangi setelah tabel stabil.');
                const rows=this.rows();if(!rows.length&&total)throw new Error('Tabel kosong saat pagination.');
                for(const row of rows){const key=C.rowKey(this.scope,row);if(seen.has(key))throw new Error('RO duplikat atau pagination berulang.');seen.add(key);all.push(row);}
                if(report.last>=total){if(all.length!==total)throw new Error('Cakupan baris tidak lengkap.');return all;}
                if(!await this.changePage(this.table().wrapper.querySelector('.p-paginator-next'),guard))throw new Error('Halaman berikutnya tidak tersedia padahal data belum lengkap.');
            }
            throw new Error('Batas 200 halaman tercapai. Persempit filter.');
        }
        async locate(item,job,guard=async()=>{}){
            await this.first(guard);
            for(let page=0;page<200;page++){
                await guard();const rows=this.rows(),matches=rows.filter(row=>C.rowKey(job.scope,row)===item.key);
                if(matches.length>1)throw new Error('Identitas RO duplikat.');
                if(matches.length===1)return matches[0];
                const report=this.report();if(report.last>=report.total)return null;
                if(!await this.changePage(this.table().wrapper.querySelector('.p-paginator-next'),guard))return null;
            }
            throw new Error('Baris tidak ditemukan dalam batas pagination.');
        }
        dialog(){
            const dialogs=[...this.doc.querySelectorAll('[role="dialog"],.p-dialog')].filter(visible)
                .filter(el=>!el.parentElement?.closest('[role="dialog"],.p-dialog'));
            if(dialogs.length!==1)throw new Error('Dialog persetujuan tidak unik.');
            return dialogs[0];
        }
        checkDialog(item,job){
            const dialog=this.dialog(),value=text(dialog);
            if(!/Data Capaian RO/i.test(value)||!/Status Validasi/i.test(value))throw new Error('Dialog bukan persetujuan capaian RO.');
            const route=value.match(/P\s*\/\s*K\s*\/\s*KRO\s*\/\s*RO\s*:?\s*([a-z0-9.\s]+?)(?=\s+(?:Uraian\s+RO|Validasi|Belanja|Keterangan)\b|$)/i);
            if(!new RegExp(`Satker\\s*:?\\s*${job.scope.satker}\\b`,'i').test(value)
                ||!new RegExp(`Periode\\s*:?\\s*0?${Number(job.scope.periode)}\\b`,'i').test(value)
                ||!route||compact(route[1])!==compact(`${item.program}${item.kegiatan}${item.ro}`))throw new Error('Identitas dialog berbeda dari antrean. Tidak dikirim.');
            return dialog;
        }
        statusControl(dialog){
            const labels=[...dialog.querySelectorAll('label')].filter(el=>compact(text(el))==='statusvalidasi');
            for(const label of labels){const id=label.getAttribute('for');if(id){const el=this.doc.getElementById(id);if(el&&dialog.contains(el))return el.closest('p-dropdown,p-select,.p-dropdown,.p-select')||el;}}
            const controls=[...dialog.querySelectorAll('p-dropdown,p-select,.p-dropdown,.p-select,select,[role="combobox"]')].filter(visible);
            const outer=controls.filter(el=>!controls.some(parent=>parent!==el&&parent.contains(el)));
            if(outer.length!==1)throw new Error('Pilihan Status Validasi tidak unik.');
            return outer[0];
        }
        async open(row,item,job,guard){
            if(this.doc.querySelector('[role="dialog"]')&&[...this.doc.querySelectorAll('[role="dialog"]')].some(visible))throw new Error('Tutup dialog yang masih terbuka sebelum mulai.');
            const fresh=this.rows().find(r=>C.rowKey(job.scope,r)===item.key);
            if(!fresh||C.nextAction(item,fresh)!=='submit')throw new Error('Data/status baris berubah sebelum membuka dialog.');
            const {cols}=this.table();const cell=fresh.element.cells[cols.action];
            const buttons=[...cell.querySelectorAll('button,[role="button"]')].filter(enabled).filter(el=>!el.closest('button')||el.tagName==='BUTTON');
            if(buttons.length!==1)throw new Error('Tombol Action Validasi tidak unik/tidak aktif.');
            await guard();buttons[0].click();
            const dialog=await this.wait(()=>{try{return this.checkDialog(item,job);}catch{return false;}},'Dialog validasi tidak terbuka/identitas tidak cocok.',guard);
            const control=this.statusControl(dialog);
            if(control.tagName==='SELECT'){
                const option=[...control.options].find(o=>norm(text(o))==='setuju');if(!option)throw new Error('Pilihan Setuju tidak ditemukan.');
                await guard();control.value=option.value;control.dispatchEvent(new Event('change',{bubbles:true}));
            }else{
                const trigger=control.matches('[role="combobox"]')?control:
                    [...control.querySelectorAll('[role="combobox"],.p-dropdown-trigger,.p-select-dropdown')].find(enabled)||control;
                if(!enabled(trigger))throw new Error('Status Validasi tidak aktif.');
                await guard();trigger.click();
                const option=await this.wait(()=>{
                    const list=[...this.doc.querySelectorAll('[role="option"],.p-dropdown-item,.p-select-option')].filter(el=>visible(el)&&norm(text(el))==='setuju');
                    if(list.length>1)throw new Error('Pilihan Setuju tidak unik.');return list[0];
                },'Pilihan Setuju tidak ditemukan.',guard);
                await guard();option.click();
            }
            await this.wait(()=>this.isAgreed(this.statusControl(this.checkDialog(item,job))),'Status Setuju belum terpilih.',guard);
        }
        isAgreed(control){return norm(control.tagName==='SELECT'?text(control.selectedOptions[0]):text(control.querySelector('.p-dropdown-label,.p-select-label')||control))==='setuju';}
        async submit(row,item,job,guard){
            await guard();const dialog=this.checkDialog(item,job);
            if(!this.isAgreed(this.statusControl(dialog)))throw new Error('Status bukan Setuju. Tidak dikirim.');
            await guard();const latestDialog=this.checkDialog(item,job);
            if(!this.isAgreed(this.statusControl(latestDialog)))throw new Error('Status bukan Setuju. Tidak dikirim.');
            const fresh=this.rows().find(r=>C.rowKey(job.scope,r)===item.key);
            if(!fresh||fresh.status!=='pending'||C.fingerprint(fresh)!==item.fingerprint)throw new Error('Data/status baris berubah saat dialog terbuka. Tidak dikirim.');
            const buttons=[...latestDialog.querySelectorAll('button')].filter(el=>enabled(el)&&norm(text(el))==='kirim');
            if(buttons.length!==1)throw new Error('Tombol Kirim tidak unik/tidak aktif.');
            buttons[0].click();
        }
        async verify(item,job,guard){
            try{return await this.wait(()=>{
                if(this.busy())return false;
                try{const row=this.rows().find(r=>C.rowKey(job.scope,r)===item.key);return row&&C.nextAction(item,row)==='complete';}catch{return false;}
            },'Status hijau belum terverifikasi.',guard,12000);}catch(error){await guard();return false;}
        }
    }
    root.CaputDom=CaputDom;
})(globalThis);
