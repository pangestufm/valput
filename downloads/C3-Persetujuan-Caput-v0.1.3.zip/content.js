(function(){
    'use strict';
    if(globalThis.__caputLoaded)return;globalThis.__caputLoaded=true;
    const C=CaputCore;
    let adapter;
    function currentAdapter(){
        const url=C.parseScope(location.href).url;
        if(!adapter||adapter.url!==url)adapter=new CaputDom({url});
        return adapter;
    }
    let busy=false,cancelled=false,resumeRequested=false,owner;
    async function send(kind,extra={}){
        const result=await chrome.runtime.sendMessage({kind,...extra});
        if(!result?.ok)throw new Error(result?.error||'Ekstensi tidak merespons.');return result.value;
    }
    function localGuard(){if(cancelled)throw new Error('Dihentikan pengguna.');}
    async function guardContext(job){
        localGuard();
        if(job.owner!==owner)throw new Error('Pekerjaan telah diambil alih dokumen terbaru.');
        if(C.parseScope(location.href).url!==job.scope.url)throw new Error('URL satker/periode berubah.');
        if(adapter.year()!==job.year)throw new Error('Tahun anggaran berubah.');
        const password=document.querySelector?.('input[type="password"]');
        if(password?.getClientRects().length)throw new Error('Login diperlukan. Login sendiri lalu lanjutkan pekerjaan.');
    }
    async function guard(job){
        await guardContext(job);
        if(JSON.stringify(adapter.filters())!==JSON.stringify(job.filters))throw new Error('Filter tabel berubah. Pulihkan filter yang sama sebelum melanjutkan.');
    }
    async function recoverMissingTable(job,error){
        if(error.code!=='CAPUT_TABLE_UNAVAILABLE')return false;
        try{await guardContext(job);}catch{return false;}
        const current=await send('GET').catch(()=>null);
        if(!current||current.id!==job.id||current.owner!==owner||current.revision!==job.revision||!['running','recovering'].includes(current.status))return true;
        current.connectionRetries=(current.connectionRetries||0)+1;
        current.status=current.connectionRetries>5?'paused':'recovering';
        C.record(current,current.status==='paused'?'Batas 5 refresh tercapai; tabel belum pulih. Pulihkan halaman/filter yang sama lalu lanjutkan.':
            `Tabel terputus pada URL yang sama. Refresh otomatis ${current.connectionRetries}/5; hasil Kirim sebelumnya tidak dikirim ulang.`);
        const saved=await send('SAVE',{job:current}).catch(()=>null);
        if(!saved)return true;
        if(saved.status==='paused')return true;
        await new Promise(resolve=>setTimeout(resolve,3000));
        const latest=await send('GET').catch(()=>null);
        if(!latest||latest.id!==saved.id||latest.owner!==owner||latest.revision!==saved.revision||!['running','recovering'].includes(latest.status))return true;
        try{await guardContext(latest);}catch(contextError){
            latest.status='paused';C.record(latest,contextError.message);await send('SAVE',{job:latest}).catch(()=>{});return true;
        }
        location.reload();return true;
    }
    async function loop(){
        if(busy)return;busy=true;cancelled=false;
        try{
            currentAdapter();
            const claimed=await send('CLAIM');owner=claimed?.owner;
            await adapter.ready(localGuard);
            await CaputRunner.run({get:()=>send('GET'),save:job=>send('SAVE',{job}),guard,
                locate:(...args)=>adapter.locate(...args),open:(...args)=>adapter.open(...args),
                submit:(...args)=>adapter.submit(...args),verify:(...args)=>adapter.verify(...args),
                recover:async job=>{await guard(job);location.reload();},
                finalScan:(job,check)=>adapter.scan(check),onTableUnavailable:recoverMissingTable});
        }catch(error){
            const job=await send('GET').catch(()=>null);
            if(job&&['running','recovering'].includes(job.status)){
                if(await recoverMissingTable(job,error))return;
                job.status='paused';C.record(job,error.message);await send('SAVE',{job}).catch(()=>{});
            }
        }finally{busy=false;if(resumeRequested){resumeRequested=false;void loop();}}
    }
    async function command(m){
        if(m.kind==='CANCEL'){cancelled=true;return null;}
        if(m.kind==='RESUME'){if(busy)resumeRequested=true;else void loop();return null;}
        currentAdapter();
        if(m.kind==='INFO'){
            adapter.table();
            await adapter.ready();return {scope:C.parseScope(location.href),year:adapter.year(),total:adapter.report().total,
                currentPending:adapter.rows().filter(r=>r.status==='pending').length,busy};
        }
        if(!['CHECK','CREATE'].includes(m.kind))throw new Error('Perintah tidak dikenali.');
        if(busy)throw new Error('Pemeriksaan/pekerjaan masih berjalan.');busy=true;cancelled=false;
        try{
            await adapter.ready(localGuard);
            const url=location.href,year=adapter.year(),filters=adapter.filters();
            const check=async()=>{localGuard();if(location.href!==url||adapter.year()!==year||JSON.stringify(adapter.filters())!==JSON.stringify(filters))throw new Error('Cakupan berubah saat menyusun antrean.');};
            const rows=await adapter.scan(check);await check();
            if(m.kind==='CHECK'){
                const sample=C.createJob({url,year,rows,filters,confirmed:true});
                return {total:sample.totalRows,pending:sample.queue.length,approved:sample.totalRows-sample.queue.length};
            }
            const job=C.createJob({url,year,rows,filters,confirmed:m.confirmed===true});
            await check();await send('NEW_JOB',{job});
            setTimeout(()=>void loop(),0);return {total:job.totalRows,pending:job.queue.length};
        }finally{busy=false;}
    }
    chrome.runtime.onMessage.addListener((m,_sender,reply)=>{
        command(m).then(value=>reply({ok:true,value})).catch(error=>reply({ok:false,error:error.message}));return true;
    });
    function resumeOnRoute(){
        try{currentAdapter();}catch{return;}
        send('GET').then(job=>{if(job&&['running','recovering'].includes(job.status))void loop();}).catch(()=>{});
    }
    let lastUrl=location.href;
    function routeChanged(){if(location.href===lastUrl)return;lastUrl=location.href;resumeOnRoute();}
    new MutationObserver(routeChanged).observe(document.documentElement,{childList:true,subtree:true});
    addEventListener('popstate',routeChanged);
    resumeOnRoute();
})();
