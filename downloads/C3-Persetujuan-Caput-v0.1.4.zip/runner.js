(function(root,factory){
    const api=factory(typeof module==='object'&&module.exports?require('./core.js'):root.CaputCore);
    if(typeof module==='object'&&module.exports)module.exports=api;else root.CaputRunner=api;
})(globalThis,function(C){
    'use strict';
    async function run(p) {
        let job=await p.get();
        if(!job || !['running','recovering'].includes(job.status))return;
        const id=job.id;
        const op=C.operation(job.mode);
        async function guard() {
            const fresh=await p.get();
            if(!fresh || fresh.id!==id || !['running','recovering'].includes(fresh.status))throw new Error('Dihentikan pengguna.');
            await p.guard?.(fresh);
        }
        async function save(message,item) {
            C.record(job,message,item);const saved=await p.save(job);
            if(saved?.revision!==undefined)job.revision=saved.revision;
        }
        try {
            await guard();job.status='running';await save('Memeriksa antrean tersimpan.');
            for(const item of job.queue) {
                if(item.stage==='done')continue;
                await guard();
                const row=await p.locate(item,job,guard);
                await guard();
                const action=C.nextAction(item,row);
                if(action==='pause') {
                    job.status='paused';
                    await save(item.stage==='submitting'?'Hasil Kirim sebelumnya belum dapat dipastikan. Periksa baris ini secara manual; tidak dikirim ulang otomatis.':'Baris hilang, status tidak dikenal, atau data berubah. Periksa dan buat antrean baru.',item);
                    return;
                }
                if(action==='submit') {
                    await p.open(row,item,job,guard);
                    await guard();
                    item.stage='submitting';
                    await save('Checkpoint disimpan sebelum Kirim.',item);
                    await guard();
                    await p.submit(row,item,job,guard);
                    const approved=await p.verify(item,job,guard);
                    await guard();
                    if(!approved) {
                        job.recoveries++;
                        if(job.recoveries>3){job.status='paused';await save('Batas pemulihan tercapai. Periksa hasil persetujuan secara manual.',item);return;}
                        job.status='recovering';await save('Hasil Kirim belum terlihat. Refresh lalu cek status tanpa mengirim ulang.',item);
                        await p.recover(job);
                        return;
                    }
                }
                item.stage='done';job.connectionRetries=0;await save(op.id==='confirmation'?'Status terkonfirmasi terverifikasi.':'Status hijau terverifikasi.',item);
            }
            await guard();
            const remaining=(await p.finalScan(job,guard)).filter(r=>r.status!=='approved');
            await guard();
            job.remaining=remaining.length;
            job.status=remaining.length?'paused':'done';
            await save(remaining.length?`Masih ada ${remaining.length} baris ${op.id==='confirmation'?'belum terkonfirmasi':'X/status belum dikenal'}. Tidak diproses di luar antrean awal.`:
                op.id==='confirmation'?'Selesai. Seluruh halaman dalam cakupan sudah terkonfirmasi.':'Selesai. Seluruh halaman dalam cakupan diperiksa dan tidak ada X tersisa.');
        } catch(error) {
            const current=await p.get();
            if(!current || current.id!==id || current.status==='stopped')return;
            if(current.revision!==undefined&&current.revision!==job.revision)return;
            if(error.code==='CAPUT_TABLE_UNAVAILABLE'&&p.onTableUnavailable&&await p.onTableUnavailable(job,error))return;
            job.status='paused';await save(error.message || String(error));
        }
    }
    return {run};
});
