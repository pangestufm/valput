# C3 - Persetujuan Caput MyIntress

Ekstensi Chrome/Edge lokal, versi 0.1.4. Keputusan persetujuan tetap milik pengguna. Mode Validasi mengeksekusi **Setuju lalu Kirim** untuk baris X pada kolom Validasi. Mode Konfirmasi memproses kolom Terkonfirmasi dengan catatan **sesuai**. Keduanya memerlukan pernyataan pengguna bahwa C3 pada cakupan yang sama sudah valid; tidak menilai ulang kode peringatan MyIntress, termasuk kode 07.

## Pembaruan 0.1.4: Konfirmasi

1. Pilih **Konfirmasi** di panel. Pilihan mode tidak langsung mengirim data.
2. Klik **Cek tanpa kirim** untuk melihat baris yang belum terkonfirmasi di seluruh halaman.
3. Periksa satker/periode/tahun, centang pernyataan C3, lalu klik **Konfirmasi - Setuju**.
4. Hanya teks tepat `terkonfirmasi` yang dilewati. Status lain masuk antrean. Ekstensi menggunakan **Action Konfirmasi**, membuka dialog **Tambah Catatan**, memilih **Status Terkonfirmasi = terkonfirmasi**, mengisi Catatan tepat **sesuai**, lalu klik Kirim. Status Validasi tidak diproses oleh mode ini.

Mode dan antrean disimpan bersama checkpoint, termasuk sesudah refresh. Tidak bisa berpindah ke mode lain selama antrean belum selesai; selesaikan/Lanjutkan atau periksa dan hapus riwayat pekerjaan lama secara sadar sebelum mengganti mode. Perubahan mode menghapus centang persetujuan agar keputusan tidak terbawa. Mode Validasi tetap tersedia seperti sebelumnya. Antrean versi lama tanpa atribut mode diperlakukan sebagai Validasi.

## Pembaruan 0.1.3

Jika tabel menghilang/kembali ke form filter tetapi URL detail tetap sama, pekerjaan aktif mencoba refresh otomatis hingga lima kali berturut-turut. Halaman diberi waktu siap hingga sekitar 20 detik, lalu jeda tiga detik sebelum refresh. Counter tersimpan lintas reload dan direset setelah ada RO terverifikasi hijau. Progres tetap terlihat sebagai Memulihkan halaman saat tabel belum terhubung.

Checkpoint sebelum Kirim tetap dipertahankan: sesudah halaman pulih, RO terakhir diperiksa dahulu. Jika sudah hijau, lanjut ke antrean berikutnya. Jika masih X dan hasil Kirim belum pasti, dijeda untuk pemeriksaan manual, bukan dikirim dua kali. URL, tahun, filter, identitas dan nilai baris tetap harus cocok sebelum persetujuan berikutnya.

Setelah batas percobaan tercapai, login diperlukan, atau cakupan/data berubah, pekerjaan dijeda. Lanjutkan tersedia untuk checkpoint pada URL yang sama meskipun tabel belum terhubung, tetap wajib pernyataan pengguna. Lanjutkan memulai lagi batas percobaan refresh, bukan menghapus checkpoint pengiriman. Berhenti juga membatalkan refresh berikutnya.

## Pembaruan 0.1.2

Memperbaiki pesan "Pilihan Setuju tidak ditemukan" pada dropdown MyIntress asli. Ekstensi mengeklik combobox di dalam komponen Status Validasi, menunggu opsi muncul, memilih tepat `setuju`, memeriksa pilihan dan identitas RO, baru menekan Kirim. Pembungkus `p-dropdown` bukan target klik pembuka. Tampilan tidak diubah.

## Pembaruan sebelumnya

Pembaca status sekarang mengenali ikon SPAN yang dipakai MyIntress asli. Popup memakai panel kompak 440px dengan ringkasan total/X/disetujui dan bantuan dalam bagian lipat.

Navigasi dari rekap ke detail tanpa memuat ulang halaman juga didukung. Script tersedia pada halaman layout MyIntress, tetapi pembacaan dan persetujuan hanya diaktifkan setelah URL detail satker/periode dikenali.

Jika folder yang sudah terpasang telah diperbarui, tutup dialog validasi/konfirmasi yang masih terbuka, buka halaman Extensions lalu klik **Reload** pada ekstensi C3, kemudian refresh tab MyIntress sekali agar script baru aktif. Versi pada header popup harus **0.1.4**. Tidak perlu memasang ekstensi kedua. ZIP versi lama tetap dapat disimpan sebagai backup. Jika URL masih detail satker/periode pekerjaan yang sama, pastikan pernyataan C3 lalu gunakan Lanjutkan pada antrean tersimpan; jangan membuat antrean baru untuk mengulang kiriman yang hasilnya belum pasti.

## Pasang sekali

1. Ekstrak ZIP ke folder tetap. Jangan menghapus/memindahkan folder sesudah dipasang.
2. Buka `chrome://extensions` (Chrome) atau `edge://extensions` (Edge).
3. Aktifkan **Developer mode / Mode pengembang**.
4. Klik **Load unpacked / Muat yang belum dikemas**, pilih folder yang berisi `manifest.json` ini. Izinkan akses hanya jika kamu setuju ekstensi membaca/mengoperasikan halaman MyIntress.
5. Sematkan ekstensi lewat menu Extensions. Refresh halaman detail MyIntress yang sebelumnya sudah terbuka.

Ekstensi tidak dipasang otomatis pada browser pengguna dan belum diterbitkan di Chrome Web Store.

## Gunakan

1. Selesaikan pemeriksaan di C3. Jika masih ada hasil Perbaikan, **jangan mulai persetujuan**.
2. Buka MyIntress, pilih tahun anggaran, satker, periode, dan filter yang sama. Halaman harus **Detail Kertas Kerja Capaian RO** dengan URL berawalan `https://myintress.kemenkeu.go.id/layout/data-view/ikpaservice/kertasKerja/detailKertasKerjaCapaianRO/`.
3. Klik ikon ekstensi. Pastikan cakupan satker/periode/TA yang ditampilkan benar.
4. Pada pemakaian pertama, klik **Cek tanpa kirim**. Tombol ini hanya menghitung baris lintas halaman; tidak memilih Setuju maupun Kirim. Jika hasilnya tidak sesuai tabel atau muncul pesan struktur tidak dikenal, berhenti dan kirim pesan/screenshot kesalahannya untuk penyesuaian.
5. Setelah yakin, centang pernyataan C3 sudah valid dan keputusan setuju, lalu klik **Setujui seluruh baris X**. Proses dapat berjalan walaupun popup ditutup; jangan tutup tab MyIntress.

Cakupannya **seluruh halaman pada filter aktif di satu halaman detail satker/periode**, bukan otomatis semua satker lain. Antrean dibekukan saat mulai. Baris yang muncul belakangan tidak langsung disetujui. Antrean baru memerlukan pengecekan pengguna kembali.

## Progres dan pemulihan

- Popup dan badge menunjukkan jumlah antrean yang sudah terverifikasi hijau. **Selesai** berarti pemeriksaan ulang seluruh halaman tidak menemukan X/status tak dikenal.
- Jika menu berpindah ke menu umum pada origin yang sama, ekstensi mencoba kembali ke URL pekerjaan. Refresh biasa juga melanjutkan checkpoint. Batas pemulihan otomatis tiga kali.
- MyIntress kadang menampilkan rekap/form filter meskipun URL masih detail. Versi 0.1.3 mencoba refresh pada URL yang sama sebagaimana dijelaskan di atas, tetapi tidak menebak atau mengisi ulang filter otomatis. Jika lima refresh tidak memulihkan tabel, buka kembali detail/filter yang sama secara manual lalu Lanjutkan.
- Sesudah Kirim, hasil yang belum pasti hanya dicek ulang; tidak dikirim ulang otomatis. Jika tetap X, proses dijeda untuk pemeriksaan manual. **Lanjutkan** tidak mengabaikan pengaman ini.
- Mengganti satker/periode, tahun, filter, data baris, atau struktur tabel menyebabkan jeda. Jangan mengubahnya saat proses berjalan.
- Login/MFA tetap dilakukan sendiri. Setelah login dan memulihkan halaman/filter yang sama, centang pernyataan lalu **Lanjutkan**.
- **Berhenti** menghentikan tindakan berikutnya, bukan membatalkan persetujuan yang sudah terkirim. Pada status ambigu, cek langsung di MyIntress sebelum mengulang pekerjaan.
- **Simpan laporan** mengunduh JSON ke komputer. **Hapus riwayat lokal tab ini** membersihkan checkpoint tab tersebut setelah proses berhenti/selesai. Menghapus riwayat tidak membatalkan persetujuan MyIntress.

## Privasi dan izin

Izin situs hanya `myintress.kemenkeu.go.id`. Ekstensi tidak membaca token/cookie, tidak menyimpan kata sandi, tidak memakai API persetujuan langsung, dan tidak mengirim data ke website C3 atau server lain. Eksekusinya melalui tombol halaman dengan sesi login milik pengguna.

Identitas RO, snapshot teks tabel, status, serta progres tersimpan di `chrome.storage.local`, bukan sinkronisasi cloud. Laporan JSON dapat memuat data pekerjaan: simpan sesuai kebutuhan internal, jangan unggah sembarangan. Melepas ekstensi menghapus penyimpanan lokal ekstensi.

## Status pengujian dan batasan

- Diuji menggunakan fixture sintetis PrimeNG, berdasarkan struktur tabel/dialog pada screenshot dan pola komponen dari kode publik MyIntress.
- Ekstensi MV3 benar-benar dimuat di profil Edge terisolasi; tombol popup, antrean dua halaman, pilihan Setuju persis, checkpoint, stop/lanjut, laporan, dan pemulihan perpindahan menu diuji tanpa mengakses data produksi.
- **Pembacaan DOM halaman login asli sudah diuji secara baca-saja:** 36 baris, 34 ikon centang, 2 ikon X, nol status tidak dikenal. Aksi Setuju/Kirim pada data asli belum diuji dan tidak dijalankan selama pengembangan. Tetap lakukan Cek tanpa kirim pada pemakaian pertama. Jika MyIntress mengubah struktur, ekstensi dirancang berhenti, bukan menebak tombol.
- Bukan integrasi resmi MyIntress dan tidak menjamin layanan MyIntress selalu tersedia. Gunakan hanya dalam kewenangan dan kebijakan akses organisasi.

Website C3, GitHub, dan deployment Netlify tidak diubah oleh paket ekstensi ini.
