'use strict';
importScripts('core.js');
const C=globalThis.CaputCore;
const key=id=>`caput.job.${id}`;
const locks=new Map();
function serial(id,fn){
    const task=(locks.get(id)||Promise.resolve()).catch(()=>{}).then(fn);
    locks.set(id,task);task.finally(()=>{if(locks.get(id)===task)locks.delete(id);}).catch(()=>{});
    return task;
}
async function get(id){return (await chrome.storage.local.get(key(id)))[key(id)]||null;}
async function put(id,job){
    const previous=await get(id);job.revision=(previous?.revision||0)+1;
    await chrome.storage.local.set({[key(id)]:job});
    const done=job.queue?.filter(r=>r.stage==='done').length||0;
    await chrome.action.setBadgeText({tabId:id,text:job.status==='done'?'OK':`${done}/${job.queue?.length||0}`}).catch(()=>{});
    await chrome.action.setBadgeBackgroundColor({tabId:id,color:job.status==='done'?'#166534':'#1a56b8'}).catch(()=>{});
    return job;
}
async function stop(id,message='Dihentikan pengguna.'){
    const job=await serial(id,async()=>{const job=await get(id);if(job){job.status='stopped';C.record(job,message);await put(id,job);}return job;});
    await chrome.tabs.sendMessage(id,{kind:'CANCEL'}).catch(()=>{});return job;
}
async function contentSender(sender){
    if(sender.id!==chrome.runtime.id||!sender.tab?.id||sender.frameId!==0)throw new Error('Pengirim tidak diizinkan.');
    if(sender.documentLifecycle&&sender.documentLifecycle!=='active')throw new Error('Dokumen bukan halaman aktif.');
    if(new URL(sender.url).origin!==C.ORIGIN)throw new Error('Origin pengirim tidak diizinkan.');
    C.parseScope((await chrome.tabs.get(sender.tab.id)).url);return sender.tab.id;
}
async function handle(m,sender){
    if(m.kind==='GET')return get(await contentSender(sender));
    if(m.kind==='CLAIM'){
        const id=await contentSender(sender);
        return serial(id,async()=>{
            const job=await get(id);
            if(!job||!['running','recovering'].includes(job.status))return job;
            if(C.parseScope((await chrome.tabs.get(id)).url).url!==job.scope.url)throw new Error('Cakupan dokumen berbeda.');
            job.mode=C.operation(job.mode).id;
            job.owner=sender.documentId;return put(id,job);
        });
    }
    if(m.kind==='NEW_JOB'){
        const id=await contentSender(sender),scope=C.parseScope((await chrome.tabs.get(id)).url);
        return serial(id,async()=>{
            if(m.job.scope.url!==scope.url||m.job.c3Declaration!==true)throw new Error('Cakupan/pernyataan C3 tidak sesuai.');
            m.job.mode=C.operation(m.job.mode).id;
            const old=await get(id);if(old&&['running','recovering'].includes(old.status))throw new Error('Masih ada pekerjaan berjalan.');
            if(C.modeLocked(old)&&C.operation(old.mode).id!==m.job.mode)throw new Error('Selesaikan atau hapus antrean mode sebelumnya sebelum mengganti proses.');
            m.job.owner=sender.documentId;return put(id,m.job);
        });
    }
    if(m.kind==='SAVE'){
        const id=await contentSender(sender);
        return serial(id,async()=>{
            const old=await get(id);
            if(!old||old.id!==m.job.id||old.status==='stopped'||old.status==='paused'||old.status==='done')throw new Error('Pekerjaan tidak lagi aktif.');
            if(old.owner!==sender.documentId||m.job.revision!==old.revision)throw new Error('Checkpoint telah diperbarui dokumen lain.');
            if(m.job.scope.url!==old.scope.url||m.job.year!==old.year)throw new Error('Cakupan pekerjaan berubah.');
            if(C.operation(m.job.mode).id!==C.operation(old.mode).id)throw new Error('Mode pekerjaan tidak boleh berubah.');
            return put(id,m.job);
        });
    }
    // Popup saja. Content script tidak dapat mengendalikan tab lain.
    if(sender.id!==chrome.runtime.id||sender.url!==chrome.runtime.getURL('popup.html'))throw new Error('Perintah bukan dari popup ekstensi.');
    const id=m.tabId;if(!Number.isInteger(id))throw new Error('Tab aktif tidak ditemukan.');
    if(m.kind==='UI_STOP')return stop(id);
    if(m.kind==='UI_STATUS'){
        const tab=await chrome.tabs.get(id),scope=C.parseScope(tab.url);
        const stored=await get(id),mode=C.operation(C.modeLocked(stored)?stored.mode:m.mode).id;
        try{
            const info=await chrome.tabs.sendMessage(id,{kind:'INFO',mode});
            if(!info.ok)throw new Error(info.error);
            return {job:await get(id),info:info.value};
        }catch(error){
            const job=await get(id),latest=await chrome.tabs.get(id);
            if(!job||job.scope.url!==scope.url||C.parseScope(latest.url).url!==scope.url)throw error;
            return {job,info:null,connectionError:error.message};
        }
    }
    if(m.kind==='UI_CLEAR'){
        const job=await get(id);if(job&&['running','recovering'].includes(job.status))throw new Error('Hentikan pekerjaan sebelum menghapus riwayat.');
        await chrome.storage.local.remove(key(id));await chrome.action.setBadgeText({tabId:id,text:''});return null;
    }
    const tab=await chrome.tabs.get(id);C.parseScope(tab.url);
    if(m.kind==='UI_CHECK'||m.kind==='UI_START'){
        if(m.kind==='UI_START'&&m.confirmed!==true)throw new Error('Centang pernyataan C3 sudah valid semua.');
        const old=await get(id);if(old&&['running','recovering'].includes(old.status))throw new Error('Pekerjaan masih berjalan.');
        const mode=C.operation(m.mode).id;
        if(C.modeLocked(old)&&C.operation(old.mode).id!==mode)throw new Error('Selesaikan atau hapus antrean mode sebelumnya sebelum mengganti proses.');
        const response=await chrome.tabs.sendMessage(id,{kind:m.kind==='UI_CHECK'?'CHECK':'CREATE',mode,confirmed:m.confirmed===true});
        if(!response.ok)throw new Error(response.error);return response.value;
    }
    if(m.kind==='UI_RESUME'){
        if(m.confirmed!==true)throw new Error('Centang kembali pernyataan C3 sudah valid semua.');
        const job=await serial(id,async()=>{
            const j=await get(id);if(!j||!['paused','stopped'].includes(j.status))throw new Error('Tidak ada pekerjaan yang bisa dilanjutkan.');
            if(tab.url!==j.scope.url)throw new Error('Buka kembali URL satker/periode pekerjaan yang sama.');
            if(m.mode!==undefined&&C.operation(m.mode).id!==C.operation(j.mode).id)throw new Error('Mode Lanjutkan berbeda dari pekerjaan tersimpan.');
            j.status='running';j.connectionRetries=0;C.record(j,'Dilanjutkan pengguna; kiriman yang ambigu hanya diperiksa ulang.');await put(id,j);return j;
        });
        await chrome.tabs.sendMessage(id,{kind:'RESUME'});return job;
    }
    throw new Error('Perintah tidak dikenali.');
}
chrome.runtime.onMessage.addListener((m,sender,reply)=>{
    handle(m,sender).then(value=>reply({ok:true,value})).catch(error=>reply({ok:false,error:error.message}));return true;
});
chrome.tabs.onUpdated.addListener((id,change)=>{
    if(!change.url)return;
    serial(id,async()=>{
        const job=await get(id);if(!job||!['running','recovering'].includes(job.status))return;
        if(change.url===job.scope.url)return;
        const u=new URL(change.url);
        let otherScope=null;try{otherScope=C.parseScope(change.url);}catch{}
        if(otherScope&&otherScope.url!==job.scope.url){
            job.status='paused';C.record(job,'Satker/periode atau parameter halaman berubah. Proses dijeda.');await put(id,job);return;
        }
        if(u.origin!==C.ORIGIN||!/\/layout\//.test(u.pathname)||/login|signin|auth|mfa/i.test(u.pathname)){
            job.status='paused';C.record(job,'Halaman/login berubah. Login sendiri lalu buka kembali halaman detail dan lanjutkan.');await put(id,job);return;
        }
        job.recoveries++;
        if(job.recoveries>3){job.status='paused';C.record(job,'Menu berulang kali berubah. Batas pemulihan tercapai.');await put(id,job);return;}
        job.status='recovering';C.record(job,'Menu berubah; kembali ke URL pekerjaan tanpa mengganti cakupan.');await put(id,job);
        await chrome.tabs.update(id,{url:job.scope.url});
    }).catch(()=>{});
});
chrome.tabs.onRemoved.addListener(id=>serial(id,async()=>{
    const job=await get(id);if(job){job.status='stopped';C.record(job,'Tab ditutup. Pekerjaan tidak dilanjutkan otomatis.');await chrome.storage.local.set({[key(id)]:job});}
}).catch(()=>{}));
async function pauseAll(){
    const all=await chrome.storage.local.get(null);
    for(const [k,job] of Object.entries(all))if(k.startsWith('caput.job.')&&['running','recovering'].includes(job.status)){
        job.status='paused';C.record(job,'Browser/ekstensi dimulai ulang. Lanjutkan secara manual.');await chrome.storage.local.set({[k]:job});
    }
}
chrome.runtime.onStartup.addListener(()=>pauseAll());
chrome.runtime.onInstalled.addListener(()=>pauseAll());
