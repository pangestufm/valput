(function (root, factory) {
    const api = factory();
    if (typeof module === 'object' && module.exports) module.exports = api;
    else root.CaputCore = api;
})(globalThis, function () {
    'use strict';
    const ORIGIN = 'https://myintress.kemenkeu.go.id';
    const operations=Object.freeze({
        validation:Object.freeze({id:'validation',label:'Validasi',statusHeader:'validasi',actionHeader:'validasi',fieldLabel:'Status Validasi',choice:'setuju',completed:'disetujui',note:null}),
        confirmation:Object.freeze({id:'confirmation',label:'Konfirmasi',statusHeader:'terkonfirmasi',actionHeader:'konfirmasi',fieldLabel:'Status Terkonfirmasi',choice:'terkonfirmasi',completed:'terkonfirmasi',note:'sesuai'})
    });
    function operation(mode='validation'){
        if(!Object.hasOwn(operations,mode))throw new Error('Mode proses tidak dikenali.');
        return operations[mode];
    }
    function modeLocked(job){return !!job&&(['running','recovering'].includes(job.status)||(['paused','stopped'].includes(job.status)&&job.queue.some(r=>r.stage!=='done')));}
    function normalize(value) { return String(value ?? '').replace(/\s+/g, ' ').trim(); }
    function parseScope(value) {
        const u = new URL(value);
        const m = u.pathname.match(/^\/layout\/data-view\/ikpaservice\/kertasKerja\/detailKertasKerjaCapaianRO\/(\d{6})\/(\d{1,2})\/?$/);
        if (u.origin !== ORIGIN || !m || +m[2] < 1 || +m[2] > 12) throw new Error('Buka halaman Detail Kertas Kerja Capaian RO MyIntress.');
        return {url: u.origin + u.pathname.replace(/\/$/, '') + u.search, satker: m[1], periode: m[2]};
    }
    function rowKey(scope, row) {
        const fields = [scope.satker, scope.periode, row.program, row.kegiatan, row.ro].map(normalize);
        if (fields.some(x => !x)) throw new Error('Identitas satker/periode/program/kegiatan/RO tidak lengkap.');
        return JSON.stringify(fields);
    }
    // Simpan nilai kanonik, bukan hash singkat yang dapat bertabrakan.
    function fingerprint(row) { return JSON.stringify((row.values || []).map(normalize)); }
    function createJob({url, year, rows, confirmed, filters = [], mode='validation'}) {
        const op=operation(mode);
        if (confirmed !== true) throw new Error('Nyatakan bahwa seluruh hasil C3 untuk cakupan ini sudah valid.');
        const scope = parseScope(url), keys = new Set(), queue = [];
        if (!rows.length) throw new Error('Tidak ada baris capaian output pada tabel.');
        for (const row of rows) {
            const key = rowKey(scope, row);
            if (keys.has(key)) throw new Error('Identitas RO duplikat. Proses dihentikan agar tidak salah baris.');
            keys.add(key);
            if (!['pending', 'approved'].includes(row.status)) throw new Error(`Status ${op.label} tidak dikenali. Tidak ada persetujuan yang dikirim.`);
            if (row.status === 'pending') queue.push({key, program:row.program, kegiatan:row.kegiatan, ro:row.ro,
                fingerprint:fingerprint(row), stage:'pending'});
        }
        return {id:globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random()}`, scope, year,
            filters, mode:op.id, c3Declaration:true, totalRows:rows.length, queue, status:'running', recoveries:0,
            createdAt:new Date().toISOString(), updatedAt:new Date().toISOString(), message:'Antrean siap.', log:[]};
    }
    function nextAction(item, row) {
        if (!row || fingerprint(row) !== item.fingerprint) return 'pause';
        if (row.status === 'approved') return 'complete';
        if (row.status !== 'pending' || item.stage === 'submitting') return 'pause';
        return 'submit';
    }
    function record(job, message, item) {
        job.message = message;
        job.updatedAt = new Date().toISOString();
        job.log.push({time:job.updatedAt, ro:item ? `${item.program}.${item.kegiatan}.${item.ro}` : '', message});
        job.log = job.log.slice(-2000);
        return job;
    }
    return {ORIGIN,operation,modeLocked,normalize,parseScope,rowKey,fingerprint,createJob,nextAction,record};
});
